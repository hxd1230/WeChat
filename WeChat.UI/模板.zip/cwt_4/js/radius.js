$(document).ready(function(){ 	
						   
						   
	// radius Box
	$('.content_resize, .fbg_resize').css({"border-radius": "28px", "-moz-border-radius":"28px", "-webkit-border-radius":"28px"});
	$('a.rm').css({"border-radius": "6px", "-moz-border-radius":"6px", "-webkit-border-radius":"6px"});
	// end radius Box
	 
});	